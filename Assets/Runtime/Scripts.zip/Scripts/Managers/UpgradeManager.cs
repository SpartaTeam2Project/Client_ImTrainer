using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// 한 판의 증강 Level, 선택 weight, 효과 배율을 보관하는 프로토타입 Manager.
/// PlayerManager가 같은 GameObject에 생성하며, 별도의 Managers 등록은 필요하지 않다.
/// input: Numpad 1/2/3 => 현재 선택지 선택 => Level 증가 => 배율 재계산 => 다음 선택지 출력.
/// output: PlayerManager가 이동/피해/경험치를 전달할 때 읽는 세 배율과 Console 관찰 로그.
/// </summary>
[DisallowMultipleComponent]
public sealed class UpgradeManager : MonoBehaviour
{
    private const int CHOICE_COUNT = 3;

    /// <summary>
    /// 증강 하나의 정의. 효과는 비율이며 0.2는 +20%, -0.2는 -20%를 의미한다.
    /// 세 효과를 한 정의에 함께 넣을 수 있고, 보유 Level은 정의와 분리해 Manager가 보관한다.
    /// </summary>
    [Serializable]
    public sealed class UpgradeDefinition
    {
        public string Id;
        public string Name;
        [Min(1)] public int MaxLevel;
        [Min(0f)] public float Weight;
        public float MoveSpeedPerLevel;
        public float ReceivedDamagePerLevel;
        public float ExperiencePerLevel;

        public UpgradeDefinition(string id, string name, int maxLevel, float weight,
            float moveSpeedPerLevel, float receivedDamagePerLevel, float experiencePerLevel)
        {
            Id = id;
            Name = name;
            MaxLevel = maxLevel;
            Weight = weight;
            MoveSpeedPerLevel = moveSpeedPerLevel;
            ReceivedDamagePerLevel = receivedDamagePerLevel;
            ExperiencePerLevel = experiencePerLevel;
        }
    }

    [Header("증강 정의 - 변경 후 새 판에서 테스트")]
    [SerializeField] private UpgradeDefinition[] _definitions =
    {
        new UpgradeDefinition("move_speed", "이동속도 증가", 1, 1f, 0.2f, 0f, 0f),
        new UpgradeDefinition("damage_reduction", "받는 피해 감소", 2, 1f, 0f, -0.2f, 0f),
        new UpgradeDefinition("experience", "획득 경험치 증가", 3, 1f, 0f, 0f, 0.2f),
        new UpgradeDefinition("risky_growth", "받는 피해 증가 + 경험치 증가", 1, 0.01f, 0f, 0.1f, 0.2f)
    };

    [Header("프로토타입")]
    [SerializeField] private bool _enableNumpadInput = true;
    [SerializeField] private bool _logAppliedValues = true;

    private readonly Dictionary<string, int> _levels = new Dictionary<string, int>();
    private readonly List<UpgradeDefinition> _choices = new List<UpgradeDefinition>(CHOICE_COUNT);
    private readonly List<UpgradeDefinition> _candidates = new List<UpgradeDefinition>();
    private PlayerManager _playerManager;
    private bool _active;
    private int _offerNumber;

    public float MoveSpeedMultiplier { get; private set; } = 1f;
    public float ReceivedDamageMultiplier { get; private set; } = 1f;
    public float ExperienceMultiplier { get; private set; } = 1f;
    public IReadOnlyList<UpgradeDefinition> CurrentChoices => _choices;

    private void Update()
    {
        if (!_enableNumpadInput || !CanSelect())
        {
            return;
        }

        var keyboard = Keyboard.current;
        if (keyboard == null)
        {
            return;
        }

        // 위쪽 숫자 키가 아닌 Numpad만 읽는다. 한 프레임에 여러 키를 눌러도 한 번만 선택한다.
        // 키 번호는 증강 종류가 아니라, 방금 Console에 출력된 선택지 순서다.
        if (keyboard.numpad1Key.wasPressedThisFrame) TrySelectChoice(0);
        else if (keyboard.numpad2Key.wasPressedThisFrame) TrySelectChoice(1);
        else if (keyboard.numpad3Key.wasPressedThisFrame) TrySelectChoice(2);
    }

    /// <summary>
    /// input: 새 Player를 소유한 PlayerManager => output: Level 0, 배율 1, 첫 선택지.
    /// 동일 Manager를 재사용해도 이전 판의 Level과 최대레벨 제외 상태가 남지 않는다.
    /// </summary>
    public void BeginStage(PlayerManager playerManager)
    {
        EndStage();
        if (playerManager == null || _definitions == null)
        {
            Debug.LogError("[증강] PlayerManager 또는 증강 정의가 없습니다.", this);
            return;
        }

        foreach (var definition in _definitions)
        {
            if (definition == null || string.IsNullOrWhiteSpace(definition.Id) ||
                _levels.ContainsKey(definition.Id) || definition.MaxLevel < 1 ||
                !IsFinite(definition.Weight) || definition.Weight < 0f ||
                !IsFinite(definition.MoveSpeedPerLevel) || !IsFinite(definition.ReceivedDamagePerLevel) ||
                !IsFinite(definition.ExperiencePerLevel))
            {
                Debug.LogError("[증강] Id 중복/누락, MaxLevel 또는 효과/weight 설정을 확인하세요.", this);
                EndStage();
                return;
            }

            _levels.Add(definition.Id, 0);
        }

        _playerManager = playerManager;
        _active = true;
        RefreshChoices();
    }

    /// <summary>
    /// 보유 Level/선택지/플레이어 참조를 비우고 효과 배율을 모두 1로 되돌린다.
    /// </summary>
    public void EndStage()
    {
        _active = false;
        _playerManager = null;
        _levels.Clear();
        _choices.Clear();
        _candidates.Clear();
        _offerNumber = 0;
        MoveSpeedMultiplier = 1f;
        ReceivedDamageMultiplier = 1f;
        ExperienceMultiplier = 1f;
    }

    /// <summary>증강 Id의 현재 Level을 반환한다. 보유하지 않은 Id는 0.</summary>
    public int GetLevel(string id)
    {
        return id != null && _levels.TryGetValue(id, out var level) ? level : 0;
    }

    /// <summary>
    /// 실제 추첨에 쓰는 weight를 반환한다. 최대레벨/없는 Id는 0.
    /// 정의의 Weight는 보존하므로 다음 판에는 원래 weight로 다시 시작한다.
    /// </summary>
    public float GetWeight(string id)
    {
        if (_definitions != null)
        {
            foreach (var definition in _definitions)
            {
                if (definition != null && definition.Id == id)
                {
                    return GetLevel(id) >= definition.MaxLevel ? 0f : definition.Weight;
                }
            }
        }

        return 0f;
    }

    /// <summary>
    /// input: 현재 선택지의 0부터 시작하는 index => output: 선택 성공 여부.
    /// Level 증가 => 전체 보유 효과를 기준값 대비 합산 => 세 배율 갱신 => 다음 선택지 추첨.
    /// 일시정지/사망/잘못된 index/최대레벨에서는 Level을 올리지 않는다.
    /// </summary>
    public bool TrySelectChoice(int choiceIndex)
    {
        if (!CanSelect() || choiceIndex < 0 || choiceIndex >= _choices.Count)
        {
            return false;
        }

        var chosen = _choices[choiceIndex];
        if (GetWeight(chosen.Id) <= 0f)
        {
            return false;
        }

        var previousLevel = GetLevel(chosen.Id);
        _levels[chosen.Id] = previousLevel + 1;

        // 이전 배율에 다시 곱하지 않는다. 매번 보유 Level에서 재계산해 선택 순서와 무관하게 합산한다.
        var speedBonus = 0f;
        var damageChange = 0f;
        var xpBonus = 0f;
        foreach (var definition in _definitions)
        {
            var level = GetLevel(definition.Id);
            speedBonus += definition.MoveSpeedPerLevel * level;
            damageChange += definition.ReceivedDamagePerLevel * level;
            xpBonus += definition.ExperiencePerLevel * level;
        }

        MoveSpeedMultiplier = Mathf.Max(0f, 1f + speedBonus);
        ReceivedDamageMultiplier = Mathf.Max(0f, 1f + damageChange);
        ExperienceMultiplier = Mathf.Max(0f, 1f + xpBonus);

        Debug.Log($"[증강 선택] {chosen.Name}: Lv.{previousLevel} => Lv.{GetLevel(chosen.Id)}/{chosen.MaxLevel}, " +
            $"다음 추첨 weight={GetWeight(chosen.Id):0.###}\n" +
            $"[증강 합계] 이동 x{MoveSpeedMultiplier:0.###} (실제 속도 {_playerManager.Speed:0.###}), " +
            $"받는 피해 x{ReceivedDamageMultiplier:0.###}, 획득 경험치 x{ExperienceMultiplier:0.###}", this);

        RefreshChoices();
        return true;
    }

    /// <summary>실제 피격 시, 원래 피해/보정 피해/체력 변화를 Console에서 비교한다.</summary>
    public void LogDamage(float original, float applied, float healthBefore, float healthAfter)
    {
        if (_active && _logAppliedValues)
        {
            Debug.Log($"[증강 관찰: 피해] {original:0.###} => {applied:0.###} " +
                $"(x{ReceivedDamageMultiplier:0.###}), HP {healthBefore:0.###} => {healthAfter:0.###}", this);
        }
    }


    private bool CanSelect()
    {
        return _active && _playerManager != null && _playerManager.IsAlive &&
            Managers.Instance != null && Managers.Instance.IsSimulationRunning;
    }

    /// <summary>
    /// weight > 0인 후보에서 최대 3개를 중복 없이 추첨한다.
    /// 한 개를 뽑을 때마다 후보에서 제거한다. 후보가 3개 이하이면 낮은 weight도 모두 포함된다.
    /// </summary>
    private void RefreshChoices()
    {
        _choices.Clear();
        _candidates.Clear();
        foreach (var definition in _definitions)
        {
            if (GetWeight(definition.Id) > 0f)
            {
                _candidates.Add(definition);
            }
        }

        while (_choices.Count < CHOICE_COUNT && _candidates.Count > 0)
        {
            double totalWeight = 0;
            foreach (var candidate in _candidates) totalWeight += GetWeight(candidate.Id);
            var roll = UnityEngine.Random.value * totalWeight;
            var selectedIndex = _candidates.Count - 1;
            for (var i = 0; i < _candidates.Count; i++)
            {
                roll -= GetWeight(_candidates[i].Id);
                if (roll < 0)
                {
                    selectedIndex = i;
                    break;
                }
            }

            // Random.value는 1도 반환할 수 있다. 그 경계에서는 마지막 유효 후보를 사용한다.
            _choices.Add(_candidates[selectedIndex]);
            _candidates.RemoveAt(selectedIndex);
        }

        PrintChoices();
    }

    /// <summary>선택 가능한 항목만 Numpad 번호와 다음 Level, 효과, 유효 weight로 출력한다.</summary>
    private void PrintChoices()
    {
        _offerNumber++;
        var text = new StringBuilder($"[증강 선택지 #{_offerNumber}]\n");
        if (_choices.Count == 0)
        {
            text.Append("선택 가능한 증강이 없습니다. 모든 최대레벨/weight 0 항목은 제외되었습니다.");
        }

        for (var i = 0; i < _choices.Count; i++)
        {
            var choice = _choices[i];
            text.Append($"Numpad {i + 1}: {choice.Name} | Lv.{GetLevel(choice.Id)} => {GetLevel(choice.Id) + 1}/{choice.MaxLevel}");
            if (choice.MoveSpeedPerLevel != 0f) text.Append($" | 이동 {choice.MoveSpeedPerLevel * 100f:+0.#;-0.#;0}%");
            if (choice.ReceivedDamagePerLevel != 0f) text.Append($" | 받는 피해 {choice.ReceivedDamagePerLevel * 100f:+0.#;-0.#;0}%");
            if (choice.ExperiencePerLevel != 0f) text.Append($" | 경험치 {choice.ExperiencePerLevel * 100f:+0.#;-0.#;0}%");
            text.AppendLine($" | weight={GetWeight(choice.Id):0.###}");
        }

        Debug.Log(text.ToString(), this);
    }

    private static bool IsFinite(float value)
    {
        return !float.IsNaN(value) && !float.IsInfinity(value);
    }
}
